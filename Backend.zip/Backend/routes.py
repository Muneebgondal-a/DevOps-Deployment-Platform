@app.route("/status")
def status():

    system = get_system_information()

    return render_template(

        "status.html",

        cpu=system["cpu"],

        memory=system["memory"],

        disk=system["disk"],

        hostname=system["hostname"],

        os=system["os"],

        release=system["release"],

        ip=system["ip"],

        current_time=system["time"]

    )